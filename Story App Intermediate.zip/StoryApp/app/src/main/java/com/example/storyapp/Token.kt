package com.example.storyapp

object Token {
    var token : String? = null
}